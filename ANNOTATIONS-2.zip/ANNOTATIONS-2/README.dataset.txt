# ANNOTATIONS > 2022-11-22 12:24pm
https://universe.roboflow.com/annotations-vzddc/annotations-juxop

Provided by a Roboflow user
License: CC BY 4.0

